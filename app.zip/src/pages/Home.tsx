const HomePage = () => {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-4">Home page</h2>
      <p>Welcome to our modern boilerplate with React y Vite.</p>
    </div>
  );
};

export default HomePage;
