const AboutPage = () => {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-4">About</h2>
      <p>This is a application with modern technologies in a enviroment of React..</p>
    </div>
  );
};

export default AboutPage;